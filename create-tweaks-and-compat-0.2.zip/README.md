Custom personal datapack meant to add some small recipe changes to Create as well as compatability recipes between add-ons
